# PMUY Frontend Application

This is a simple frontend-only prototype for the Pradhan Mantri Ujjwala Yojana (PMUY) subsidy application.

## Features

- Form to apply using Aadhar number and income
- Calculates subsidy based on income
- Shows approval/rejection with details
- No backend – purely frontend logic

## Tech Stack

- HTML
- CSS
- JavaScript

## How to Run

1. Download the files
2. Open `apply.html` in any browser
3. Fill the form and see results

## Note

Backend is not implemented due to time constraints.
